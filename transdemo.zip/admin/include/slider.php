<link type="text/css" rel="stylesheet" media="all" href="slider-done/css/banner-slider.css" />
 <script type="text/javascript" src="slider-done/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="slider-done/js/jssor.slider.mini.js"></script>
     <script type="text/javascript" src="slider-done/js/banner-slider.js"></script>
       
<br/><br/>
<div id="slider1_container" style="position: relative; width: 1100px;
        height: 380px; overflow: hidden; border:1px solid #03F;border-radius:3px;">
 
        <!-- Loading Screen --> 
        <div u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity:0.7; position: absolute; display: block;

                background-color: #000; top: 0px; left: 0px;width: 100%; height:100%;"> 
            </div> 
            <div style="position: absolute; display: block; background: url(img/loading.gif) no-repeat center center;

                top: 0px; left: 0px;width: 100%;height:100%;">
            </div> 
        </div> 
 
        <!-- Slides Container --> 
        <div u="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 1100px; height: 380px;
            overflow: hidden;">
            <div>
                <img u="image" src="images/01.jpg" />
                <div u="caption" t="T|IB" t2="R" d=-600 class=captionOrange style="position: absolute; top: 90px; left: 720px; width: 160px;
                    height: 90px;  line-height: 90px;">
                    PTC
                </div>
            </div>
            <div> 
                <img u="image" src="images/02.jpg" />
                <div u=caption t="T|IE*IE" d=-1600 du=3800 t2="B" class="captionOrange" style="position:absolute; left:20px; top: 310px; width:330px; height:30px;">
                    Paliwal Transport Corporation
                </div>
            </div>
            
            <div>
                <img u="image" src="images/04.jpg" />
                <div u="caption" t="T|IB" t2="R" d=-600 class=captionOrange style="position: absolute; top: 90px; left: 720px; width: 160px;
                    height: 90px;  line-height: 90px;">
                    PTC
                </div>
            </div>

        </div> 
                    <!-- Share Button Styles -->
            <!-- Example to add fixed static share buttons in slider END -->
        <!-- bullet navigator container -->
        <div u="navigator" class="jssorb03" style="bottom: 16px; right: 6px;">
            <!-- bullet navigator item prototype -->
            <div u="prototype"><div u="numbertemplate"></div></div>
        </div>
        <!--#endregion Bullet Navigator Skin End -->
        <!-- Arrow Left -->
        <span u="arrowleft" class="jssora20l" style="top: 123px; left: 8px;">
        </span>
        <!-- Arrow Right -->
        <span u="arrowright" class="jssora20r" style="top: 123px; right: 8px;">
        </span>
        
    </div>