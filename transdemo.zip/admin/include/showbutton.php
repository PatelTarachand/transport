<div class="row-fluid">
            <div class="span12">
          
            <input type="button" class="btn btn-primary" style="float:right; margin-top:30px" name="addnew" id="addnew" onClick="add();" value="Show List">
            </div>
            </div>