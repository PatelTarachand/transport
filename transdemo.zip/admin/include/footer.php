<footer>
	<div class="inner-footer dark">

		<div class="about column3">
			<h4>Contact No.</h4>
			<ul>
				<li><a href="#">+91-8349300663 </a></li>
				<li><a href="#">+91-8349300773 </a></li>
                <li><a href="#">+91-8349300778  </a></li>
                <li><a href="#">+91-8349236688  </a></li>
                <li><a href="#">+91-8349269955  </a></li>
				
			</ul>
		</div>

		<div class="service column3">
			<h4>Our Services</h4>
			<ul>
				<li><a href="#">Cement Transportation</a></li>
				<li><a href="#">Clinker Transportation</a></li>
				<li><a href="#">FlyAsh Transportation</a></li>
				<li><a href="#">Fertilizer transportation</a></li>
                
			</ul>
		</div>

		<div class="text-widget column3">
			<h4>ABOUT-PTC</h4>
			<p>
Paliwal Transport Corporation is concerned with cement Authorization cement compnay in india & raw material transportation, rake handling for cement (Packed) & loose material in various siding, with various industries.</p>
		</div>

		<div class="contact column3">
			<h4>Head Office</h4>
			<p>paliwaltransport2014@gmail.com</p>
			<p>+91-9838014508, +91-9839905217, +91-9450732461, +91-8969935198, +91-9955519429</p>
			<p>Location -Varanasi (U.P.)</p>
		</div>
		<div class="clear"></div>
		<!-- End Contact -->
		<div id="back-to-top">
			<a href="#top">Back to Top</a>
		</div>
	</div>
	<!-- End inner Footer -->

	<div class="end-footer">
		<div class="lastdiv">
			<div class="copyright">
				© 2015 Paliwal Transport Corporation, All Rights Reserved Desined & Devloped By <a href="http://www.trinitysolutions.in" target="_blank">
                <span style="color:#FFF; font-size:17px">Trinity Solutions</span></a>
			</div>

			<div class="f-socials">
				<a href="#"><img src="images/feed.png" alt=""></a>
				<a href="#"><img src="images/tweet.png" alt=""></a>
				<a href="#"><img src="images/fcb.png" alt=""></a>
				<a href="#"><img src="images/gplus.png" alt=""></a>
				<a href="#"><img src="images/pin.png" alt=""></a>
			</div>
		<div class="clear"></div>
		</div>
	</div>
	</footer>