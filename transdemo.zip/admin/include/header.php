<header>
		
		<div class="subheader clearfix">
			<div class="inner-subheader">
				<div class="phone">+91-9955519429, +91-9839905217 </div>

				<div class="subheader2">
                <div class="ghanshyam">Paliwal Transport Corporation</div>
              
							
				</div>
			</div>
		</div>

		<div class="row2">
		<div class="upper-header">
			
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
			</div>					
			
			<!-- Navigation -->
			<nav id="nav">
				<ul id="navlist" class="sf-menu clearfix">
					<li class="current"><a href="index.php">Home</a></li>
					<li><a href="about-us.php"> About Us</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
				</ul>
			</nav>
        	<!-- Navigation -->  
        	<div class="clear"></div>
       </div>  
       <!-- End Upper Header -->
       </div>
       <!-- End Row2 -->

	</header>