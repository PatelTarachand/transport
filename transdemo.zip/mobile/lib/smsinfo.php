<?php
$authKey = "5efd5aff081578ebd546ae644d8f21";
$senderId="PPBBZR";
$routeId=11;
$serverUrl="msg.msgclub.net";

//u3809 f37jFf ABHAYJ abhay jain 
?>